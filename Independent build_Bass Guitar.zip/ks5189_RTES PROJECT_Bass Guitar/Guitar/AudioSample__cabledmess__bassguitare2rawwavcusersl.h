// Audio data converted from WAV file by wav2sketch

