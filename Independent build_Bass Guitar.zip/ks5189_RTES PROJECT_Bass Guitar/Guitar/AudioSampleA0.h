// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleA0[3649];
