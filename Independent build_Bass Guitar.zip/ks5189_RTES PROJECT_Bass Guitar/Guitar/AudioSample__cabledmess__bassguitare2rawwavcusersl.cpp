// Audio data converted from WAV file by wav2sketch

#include "AudioSample__cabledmess__bassguitare2rawwavcusersl.h"

